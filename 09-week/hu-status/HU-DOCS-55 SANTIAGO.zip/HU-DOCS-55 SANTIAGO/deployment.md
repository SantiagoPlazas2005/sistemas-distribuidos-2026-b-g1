# Deployment Topology

> Defines how the system is composed and run in each environment. Any developer
> must be able to start the complete system by following only this document and
> the repositories it names.

---

## 1. Overview

```
┌──────────────────────────────── Developer machine ─────────────────────────────────┐
│                                                                                     │
│   Browser ──▶ synkro-front :5173 (published)                                        │
│                 └─ serves the four portals as remotes under /remotes/<domain>/      │
│   Browser ──▶ synkro-api-gateway :8000 (published) ── /api/v1/...                   │
│                                                                                     │
│   ┌──────────────────────────── network: platform ────────────────────────────┐     │
│   │                                                                            │    │
│   │   synkro-auth-api ─────────┐                                               │    │
│   │   synkro-customers-api ────┤                                               │    │
│   │   synkro-products-api ─────┼──▶ synkro-db (shared instance)                │    │
│   │   synkro-sales-api ────────┤     ├ auth_schema                             │    │
│   │   synkro-workflow ─────────┘     ├ customers_schema                        │    │
│   │     │ (saga steps, service token)├ products_schema                         │    │
│   │     │                            ├ sales_schema                            │    │
│   │     │                            └ workflow_schema                         │    │
│   │     │                                                                      │    │
│   │   synkro-worker ──(low-stock job, service token)──▶ synkro-products-api    │    │
│   │                                                                            │    │
│   └────────────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

- Every container joins one network, `platform`. Services and the database declare `expose`, never `ports`: they are reachable inside the network and not from outside.
- Only `synkro-api-gateway` and `synkro-front` publish ports to the host, together with the observability tools (§8). A published domain service would let any client skip the gateway, its rate limit and its correlation.
- One PostgreSQL instance per environment holds all domain schemas and the workflow's saga store, defined and started by `synkro-infra` (ADR-009). Each `-db` repository and `synkro-workflow` own only the migrations of their schema. The system has no message broker in the MVP (ADR-007).
- `synkrotech_db`, its init script and its per-schema users were never provisioned: they are removed from this document, and nothing is migrated.

---

## 2. Reserved Ports

| Port | Published to the host | Service | Description |
|------|-----------------------|---------|-------------|
| 8000 | Yes | `synkro-api-gateway` | The only entry point to the API |
| 5173 | Yes | `synkro-front` | The web application; serves the portals' remotes |
| 3000 | Yes | Grafana | Dashboards over metrics and logs (§8) |
| 9090 | Yes | Prometheus | Metrics store (§8) |
| 8080 | No | Every `-api`, `synkro-workflow`, each portal | HTTP port inside the network, reached by service name (e.g. `synkro-sales-api:8080`) |
| 5432 | No | `synkro-db` | PostgreSQL shared instance inside the network, reached by service name; holds `auth_schema`, `customers_schema`, `products_schema`, `sales_schema` and `workflow_schema` |

`synkro-worker` listens on no port.

---

## 3. Composition

The repositories are cloned as siblings in one workspace. Each one brings its own `deploy/compose.yml`, and `synkro-infra` only puts them together:

| Repository | Brings |
|---|---|
| `synkro-infra` | the `include` list, the `platform` network, **the PostgreSQL instance** (`synkro-db`) with its init script, observability and the development keys |
| each `synkro-<domain>-db` | its Flyway migration runner only (no database service) |
| each `synkro-<domain>-api`, `synkro-worker` | its own service |
| `synkro-workflow` | its service and its Flyway migration runner for `workflow_schema` (no database service) |
| `synkro-api-gateway`, `synkro-front`, each portal | its own service |

```yaml
# synkro-infra/compose.yml (excerpt)
services:
  synkro-db:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: synkro
      POSTGRES_USER: ${DB_ADMIN_USER}
      POSTGRES_PASSWORD: ${DB_ADMIN_PASSWORD:?set DB_ADMIN_PASSWORD in .env}
    volumes:
      - synkro-db-data:/var/lib/postgresql/data
      - ./scripts/init-schemas.sql:/docker-entrypoint-initdb.d/init-schemas.sql:ro
    expose: ["5432"]
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -d synkro"]
    networks: [platform]

include:
  - ../synkro-auth-db/deploy/compose.yml
  - ../synkro-auth-api/deploy/compose.yml
  # … the same pair for customers, products and sales
  - ../synkro-workflow/deploy/compose.yml
  - ../synkro-worker/deploy/compose.yml
  - ../synkro-api-gateway/deploy/compose.yml
  - ../synkro-front/deploy/compose.yml
  # … each portal

volumes:
  synkro-db-data:
networks:
  platform: { name: platform }
```

A missing sibling fails visibly when the platform starts; nothing is skipped silently. Each domain can also be started alone from its own repositories.

---

## 4. Database Instance and Schemas

One PostgreSQL instance per environment holds all domain schemas (ADR-009). `synkro-infra` defines and starts it; each `-db` repository and `synkro-workflow` own only the migrations of their schema.

| Environment | Instance | Database | Schemas | Defined by |
|---|---|---|---|---|
| develop | `synkro-db` | `synkro` | `auth_schema`, `customers_schema`, `products_schema`, `sales_schema`, `workflow_schema` | `synkro-infra` |
| qa | `synkro-db` | `synkro` | same | `synkro-infra` |
| main | `synkro-db` | `synkro` | same | `synkro-infra` |

| Schema | Migrated by | Used only by |
|---|---|---|
| `auth_schema` | `synkro-auth-db` | `synkro-auth-api` |
| `customers_schema` | `synkro-customers-db` | `synkro-customers-api` |
| `products_schema` | `synkro-products-db` | `synkro-products-api` |
| `sales_schema` | `synkro-sales-db` | `synkro-sales-api` |
| `workflow_schema` | `synkro-workflow` | `synkro-workflow` |

The init script (`synkro-infra/scripts/init-schemas.sql`) creates the empty schemas and the `NOLOGIN` roles on the instance's first start. It runs only once (PostgreSQL skips `docker-entrypoint-initdb.d/` when the data volume already exists).

```yaml
# synkro-customers-db/deploy/compose.yml (excerpt; exact image tags are pinned in the repository)
services:
  customers-db-migrate:
    image: flyway/flyway:11-alpine
    profiles: [tooling]              # never started by `up`
    depends_on:
      synkro-db: { condition: service_healthy }
    environment:
      FLYWAY_URL: jdbc:postgresql://synkro-db:5432/synkro?currentSchema=customers_schema
      FLYWAY_USER: ${CUSTOMERS_DB_USER}
      FLYWAY_PASSWORD: ${CUSTOMERS_DB_PASSWORD:?set CUSTOMERS_DB_PASSWORD in .env}
    volumes: ["../:/workspace:ro"]
    command: ["-workingDirectory=/workspace", "-configFiles=flyway.toml", "migrate"]
    networks: [platform]

networks:
  platform: { external: true }
```

No `-db` repository defines a `postgres` service: the instance belongs to `synkro-infra`. Credentials come from the environment (`.env`, never committed); no password is written in any repository.

---

## 5. Migrations

- The schema of each domain lives **only** in its `-db` repository (ADR-005 Decision 2, unchanged by ADR-009). Services never run migrations at startup.
- A migration is applied **before** deploying the service version that needs it; a breaking change is split into two releases (expand, then contract).
- Each runner uses a pinned image, waits for the shared instance to be healthy, mounts its repository read-only and never starts with the platform.

```bash
# from synkro-infra, once per schema, and after pulling new migrations
docker compose --env-file .env run --rm customers-db-migrate            # apply
docker compose --env-file .env run --rm customers-db-migrate info       # applied and pending versions
docker compose --env-file .env run --rm customers-db-migrate validate   # checksums of applied migrations
```

Running `migrate` a second time applies zero changes.

---

## 6. Configuration

### Environment files

`synkro-infra/env/` holds one example per environment — `.env.develop.example`, `.env.qa.example`, `.env.main.example` — with variable names and placeholders, never values. The real `.env` is created from the example and is never committed. In `qa` and `main`, secrets come from the environment's secret store. Every variable a service reads appears in the example of each environment.

### Database credentials

Each domain has two credential pairs in the shared instance, so the service never holds the owner's rights:

| Pair | Used by | Rights |
|---|---|---|
| `<DOMAIN>_DB_USER` / `<DOMAIN>_DB_PASSWORD` | the init script (to create the schema's objects) and the migration runner | owner of the domain's schema |
| `<DOMAIN>_APP_USER` / `<DOMAIN>_APP_PASSWORD` | the service | member of `<domain>_writer` only; created by the `-infra` init script on the instance's first start; a `03_dcl` migration grants it `<domain>_writer` using only its name (`FLYWAY_PLACEHOLDERS_APP_USER`), never its password (`06-data/models.md`, principle 6) |

`<DOMAIN>` is `AUTH`, `CUSTOMERS`, `PRODUCTS`, `SALES` or `WORKFLOW`. Every password is required (`${VAR:?…}`): a missing one stops the platform with a clear message.

### Variables per service

| Service | Variables |
|---|---|
| `synkro-auth-api` | `SPRING_DATASOURCE_URL=jdbc:postgresql://synkro-db:5432/synkro?currentSchema=auth_schema`, `SPRING_DATASOURCE_USERNAME` / `_PASSWORD` (`AUTH_APP_*`), `SPRING_FLYWAY_ENABLED=false`, `JWT_PRIVATE_KEY_FILE`, `JWT_PUBLIC_KEY`, `JWT_ACCESS_TOKEN_TTL=3600`, `JWT_REFRESH_TOKEN_TTL=604800`, `SERVICE_TOKEN_TTL=2592000`, `SERVER_PORT=8080` |
| `synkro-customers-api` | `SPRING_DATASOURCE_URL=jdbc:postgresql://synkro-db:5432/synkro?currentSchema=customers_schema`, `SPRING_DATASOURCE_USERNAME` / `_PASSWORD` (`CUSTOMERS_APP_*`), `SPRING_FLYWAY_ENABLED=false`, `JWT_PUBLIC_KEY`, `SERVER_PORT=8080` |
| `synkro-products-api` | `DATABASE_URL=postgres://${PRODUCTS_APP_USER}:${PRODUCTS_APP_PASSWORD}@synkro-db:5432/synkro?search_path=products_schema&sslmode=disable`, `JWT_PUBLIC_KEY`, `HTTP_PORT=8080` |
| `synkro-sales-api` | `DATABASE_URL=postgres://${SALES_APP_USER}:${SALES_APP_PASSWORD}@synkro-db:5432/synkro?search_path=sales_schema&sslmode=disable`, `JWT_PUBLIC_KEY`, `HTTP_PORT=8080` |
| `synkro-workflow` | `SPRING_DATASOURCE_URL=jdbc:postgresql://synkro-db:5432/synkro?currentSchema=workflow_schema`, `SPRING_DATASOURCE_USERNAME` / `_PASSWORD` (`WORKFLOW_APP_*`), `SPRING_FLYWAY_ENABLED=false`, `JWT_PUBLIC_KEY`, `SERVICE_TOKEN` (from `WORKFLOW_SERVICE_TOKEN`), `CUSTOMERS_API_URL=http://synkro-customers-api:8080`, `PRODUCTS_API_URL=http://synkro-products-api:8080`, `SALES_API_URL=http://synkro-sales-api:8080`, `HTTP_TIMEOUT=5s`, `HTTP_ATTEMPTS=3`, `SAGA_REQUEST_TIMEOUT=10s`, `SERVER_PORT=8080` |
| `synkro-worker` | `SERVICE_TOKEN` (from `WORKER_SERVICE_TOKEN`), `PRODUCTS_API_URL=http://synkro-products-api:8080`, `LOW_STOCK_EVERY=15m`, `LOW_STOCK_THRESHOLD=5`, `BATCH_SIZE=100`, `RUN_TIMEOUT=2m`, `HTTP_TIMEOUT=5s`, `HTTP_ATTEMPTS=3` |
| `synkro-api-gateway` | `CORS_ALLOWED_ORIGINS=http://localhost:5173`, `RATE_LIMIT_PER_SECOND=10` (burst `20`); upstream names live in its route files, not in variables |
| `synkro-front` | `VITE_API_BASE_URL=http://localhost:8000`, `VITE_DEV_SIGN_IN=true` in `develop` only |

- Every service that receives requests validates tokens with `JWT_PUBLIC_KEY` (ADR-006). `synkro-worker` receives no requests, so it has no public key.
- `JWT_PRIVATE_KEY_FILE` exists only in `synkro-auth-api`. Services with Flyway on the classpath keep it disabled: their schema belongs to their `-db` repository (ADR-005).
- The values above are the `develop` defaults; limits and timeouts are explained in `05-architecture/cross-cutting.md`.

### Development identity

Until the Auth domain issues real tokens, two scripts in `synkro-infra` provide identity **only in `develop`**:

| Script | What it does |
|---|---|
| `scripts/dev-keys.sh` | Generates a 2048-bit RSA key pair in `keys/`, writes `JWT_PUBLIC_KEY` to `.env` (PEM on one line, with literal `\n`), and writes `WORKFLOW_SERVICE_TOKEN` and `WORKER_SERVICE_TOKEN` with the permissions of ADR-006 |
| `scripts/dev-token.sh <subject> [minutes]` | Signs an RS256 token for a person, for manual calls and for the frontend's development sign-in |

`keys/`, `*.pem` and `.env` are ignored by git. In `qa` and `main`, the public key and the service tokens are issued by `synkro-auth-api` and stored as environment secrets; development keys never leave `develop`.

---

## 7. Network Isolation

- Every container joins the `platform` network. Services and databases declare `expose`, never `ports`, so none of them is reachable from outside the network.
- Isolation limits exposure, but it is **not** what makes a request trustworthy. Every service validates the token itself, ignores any `X-User-*` header, and accepts internal calls only with a valid service token (ADR-006).
- If a domain service were published by mistake, it would still reject every request without a valid token. The mistake itself is caught in review: no `-api`, `-db`, `synkro-workflow` or `synkro-worker` compose file may contain `ports:`.

---

## 8. Observability

| Signal | How it is produced | Where it goes |
|---|---|---|
| Logs | Structured JSON on stdout, one line per request or job run, with `correlationId`, service, route, status and duration; never tokens, passwords or personal data | `docker compose logs`; queried by `correlationId` |
| Metrics | Request count, errors and duration per route; job runs and failures in the worker; exported over OTLP | OpenTelemetry collector → Prometheus → Grafana |
| Traces | One span per request and per outgoing call, with the same `X-Correlation-Id`, exported over OTLP | OpenTelemetry collector (printed by its debug exporter in `develop`) |

- `synkro-infra/observability/` holds `otel-collector.yaml`, `prometheus.yml` and `grafana-datasources.yaml`.
- Every service sends its telemetry to `OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317`, with `OTEL_SERVICE_NAME` set to its repository name.
- A request can be followed across the gateway, the workflow and every participant by its `X-Correlation-Id`, which is also the `traceId` of any error (`05-architecture/cross-cutting.md`).

---

## 9. How to Start Everything from Scratch

```bash
# 1. Clone every repository as a sibling of synkro-infra, then:
cd synkro-infra
cp env/.env.develop.example .env        # set DB_ADMIN_PASSWORD, every *_DB_PASSWORD and *_APP_PASSWORD
./scripts/dev-keys.sh                   # develop only: key pair, JWT_PUBLIC_KEY, service tokens
./scripts/up.sh                         # checks .env, creates the platform network, starts everything (including synkro-db)

# 2. Migrate each schema (once per -db, and after pulling new migrations)
for schema in auth customers products sales; do
  docker compose --env-file .env run --rm "$schema-db-migrate"
done
docker compose --env-file .env run --rm workflow-db-migrate

# 3. Verify
docker compose ps                                        # every service healthy
curl http://localhost:8000/health                        # gateway
curl -H "Authorization: Bearer $(./scripts/dev-token.sh alice)"      http://localhost:8000/api/v1/customers              # routed and validated by synkro-customers-api
docker compose logs synkro-worker                        # one entry per low-stock run
open http://localhost:3000                               # Grafana
```

Until a schema is migrated, that domain's API answers `500 INTERNAL_ERROR` and the worker logs the failed run with its `traceId`; the next run works once the migration is applied.

---

## Correlations

* Schema per domain and shared instance → ADR-009 (supersedes ADR-005 Decision 1); migrations → ADR-005 Decision 2
* Token validation and service tokens → ADR-006
* Error format, correlation, limits and retries → `05-architecture/cross-cutting.md`
* Workflow store and worker job → ADR-007
* Gateway and frontend technology → ADR-008
* Timeout and retry configuration → `05-architecture/pattern-guide.md` §5
* Data model per domain → `06-data/models.md`
