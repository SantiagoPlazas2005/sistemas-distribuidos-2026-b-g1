Rama:

docs/correct-deployment-and-models-for-shared-instance


**Commit:**
```
docs(architecture): fix connection strings and domain headers for shared instance
```

**Título del PR:**
```
docs(architecture): fix connection strings and domain headers for shared instance
```

**Descripción del PR:**


## Description

### Summary

Fixes three oversights in the deployment and data-model corrections
merged in the previous PR: the service connection strings in §6 still
pointed to the old per-domain instances, the four domain section headers
in `models.md` still said "Instance:", and a line in §6 was duplicated.

### Changes

- **`deployment.md` §6 variables table**: all five database URLs now
  point to `synkro-db:5432/synkro` with `?currentSchema=<domain>_schema`
  (Java/JDBC) or `?search_path=<domain>_schema` (Go/libpq) instead of
  the old `<domain>-db:5432/<domain>`.
- **`deployment.md` §6 duplicated line**: removed the repeated sentence
  about required passwords.
- **`models.md` domain headers** (auth, customers, products, sales):
  changed from `**Instance:** <domain>-db · **Database and schema:**
  <domain>` to `**Schema:** <domain>_schema (shared instance)`,
  matching the saga store header that was already corrected.

### What is NOT changed

The DDL schema prefixes in the SQL blocks (`auth.system_user`,
`customers.customer`, etc.) still use the short name without `_schema`.
These will be updated in a follow-up PR once the team confirms the
`CREATE SCHEMA` naming — tracked separately from this topology
correction.

### Definition of Done

- [x] `deployment.md` §4 shows one instance per environment with 5 schemas, not 5 separate instances
- [x] Compose excerpt in §4 shows a migration runner only — no standalone postgres service in the `-db`
- [x] `deployment.md` §6 credentials say "schema" where they said "instance"; two-pair model preserved
- [x] `deployment.md` §6 connection strings point to `synkro-db` with `currentSchema` / `search_path`
- [x] `deployment.md` §9 startup narrative uses "schema" and "shared instance" consistently
- [x] `models.md` header says the schema lives in the environment's shared instance
- [x] `models.md` principle 1 titled "Schema per domain" with updated example
- [x] All four domain headers say "Schema: `<domain>_schema` (shared instance)"
- [x] Full-text search for "instance per domain", "its own instance" and "its own database" returns zero hits in both files
- [x] ADR-009 cited where ADR-005 Decision 1 was cited
- [x] Reviewed and approved by Angel (Tech Lead, ADR-009 author) and Sergio (ADR-007 author)

**Reviewers:** Angel y Sergio.

Closes HU-DOCS-55 (part of HU-11).
