## HU-DOCS-71 — Renombra los prefijos DDL a `<dominio>_schema`

- `06-data/models.md`
- `00-governance/security-policy.md`, `06-data/data-dictionary.md`
- `15-project-control/technical-backlog.md` (TD-005 resuelto)
- 05-architecture/hexagonal-architecture.md
- 05-architecture/security-threat-model.md

| Campo | Valor |
|---|---|
| Rama | `docs/rename-ddl-schema-prefixes` |
| Responsable | Santiago |
| Depende de | Ninguna |
| Prioridad | Must Have |

**Rama y commit**

```
docs/rename-ddl-schema-prefixes
```

```
docs(data): rename DDL schema prefixes to <domain>_schema

Use the real schema names in every SQL block and make schema and role creation idempotent.
```

**Descripción del PR**

## Description

### Summary

Every SQL block of `models.md` now uses the real schema names
(`auth_schema`, `customers_schema`, `products_schema`, `sales_schema`,
`workflow_schema`) instead of the short prefixes, and the creation of
schemas and roles works both in an environment (where the `synkro-infra`
init script already created them) and in the ephemeral instance of each
`-db` CI.

### Changes

- **`models.md`**: all `CREATE TABLE`, `ALTER TABLE`, `CREATE INDEX` and
  `GRANT` statements use `<domain>_schema`; V001 shown as
  `CREATE SCHEMA IF NOT EXISTS`; the role migration is idempotent (a
  `DO` block, because PostgreSQL has no `CREATE ROLE IF NOT EXISTS`);
  principle 6 explains why and who creates what (the owner was said to
  be created by the PostgreSQL image, which is no longer true with a
  shared instance); migration names renamed to
  `V001__create_<domain>_schema.sql`; the provisional note is removed.
- **Other documents**: `security-policy.md`, `security-threat-model.md`
  (E-3), `data-dictionary.md` and the two persistence examples of
  `hexagonal-architecture.md` use the schema wording.
- **`technical-backlog.md`**: TD-005 moves to "Resolved items".

### Definition of Done

- [x] No SQL statement in `models.md` uses the short schema prefix
- [x] Schema and role creation is idempotent, and the document explains why
- [x] The inline note that pointed to this HU is removed
- [x] `security-policy.md` and `data-dictionary.md` use `<domain>_schema` wording
- [x] TD-005 moves to "Resolved items" in `technical-backlog.md`
- [x] Reviewed and approved by Angel (Tech Lead) and Jordan (author of ADR-005)

**Revisores:** Angel, porque debe confirmar la idempotencia (decisión de diseño), y Jordan.

Closes HU-DOCS-71 (part of HU-13).
