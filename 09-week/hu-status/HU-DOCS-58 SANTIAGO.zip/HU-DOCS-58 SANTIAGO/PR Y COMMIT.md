## HU-DOCS-58 — Adds Products OpenAPI contract: stock reservations and alerts

- `07-api/contracts/openapi/synkro-products-api.yaml` (reservation and alert endpoints added)

| Field | Value |
|---|---|
| Branch | `docs/add-stock-reservations-and-alerts-contract` |
| Owner | Santiago |


**Rama:**
```
docs/add-stock-reservations-and-alerts-contract
```

**Commit:**
```
docs(api): add stock reservation and alert endpoints to products contract
```

**Título del PR:**
```
docs(api): add stock reservation and alert endpoints to products contract
```

**Descripción del PR:**

## Description

### Summary

Adds the 6 stock-reservation and stock-alert endpoints to
`synkro-products-api.yaml`, completing the Products domain contract.
These endpoints were decided in ADR-007 Decisions 3 and 6, registered
in ADR-004 Decision 6, and excluded from HU-DOCS-57 (which covered
only catalog, categories and manual stock adjustments).

### Changes

- **3 stock-reservation endpoints** (internal, not routed by the
  gateway): create (all lines in one transaction, with frozen
  unitPriceCents), get, and release (idempotent by status). Called
  only by the workflow's service token with `stock:reserve` and
  `stock:release`.
- **3 stock-alert endpoints** (routed by the gateway under
  `/api/v1/stock-alerts/`): list (paginated, filter by status), create
  (idempotent by partial unique index — one OPEN per product), and
  resolve (idempotent by status). Create and resolve called only by
  the worker's service token with `stock-alerts:write`; list also
  allowed to ADMIN and INVENTORY.
- **7 new schemas**: CreateStockReservationRequest,
  ReservationLineRequest, StockReservationResponse,
  ReservationLineResponse, CreateStockAlertRequest,
  StockAlertResponse, plus 2 new path parameters (ReservationId,
  AlertId).
- **2 new tags**: Stock Reservations and Stock Alerts.

### Consistency checks

- Fields match `06-data/models.md` (stock_reservation,
  stock_reservation_line, stock_alert tables).
- Invariants match `02-domain/entities-and-rules.md` (all-or-nothing
  reservation, RELEASED is final, at most one OPEN alert per product).
- Endpoints match ADR-004 Decision 6 register exactly.
- Money in unitPriceCents as integer/int64 (ADR-005 Decision 3).

### Definition of Done

- [x] `synkro-products-api.yaml` contains stock-reservation endpoints (create, get, release) from ADR-007 Decision 3
- [x] `synkro-products-api.yaml` contains stock-alert endpoints (list, create, resolve) from ADR-007 Decision 6
- [x] Reservation endpoints require stock:reserve and stock:release permissions (service token only)
- [x] Alert create and resolve require the worker's service token (stock-alerts:write)
- [x] Reservation schemas include status (RESERVED, RELEASED) and lines with frozen unitPriceCents
- [x] Reviewed and approved by Angel (Tech Lead) and Jordan (ADR-007 reviewer, saga consumer)

**Reviewers:** Angel (Tech Lead) and Jordan (reviewed ADR-007 and is the one who will implement the workflow that consumes these reservations).

Closes HU-DOCS-58 (part of HU-11).

