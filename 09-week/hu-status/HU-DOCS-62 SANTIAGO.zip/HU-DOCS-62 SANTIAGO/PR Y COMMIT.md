## HU-DOCS-62 — Updates DoD and branch conventions

- `00-governance/definition-of-done.md` (updated)
- `00-governance/git-conventions.md` (reviewed)
- `00-governance/documentation-rules.md`

| Field | Value |
|---|---|
| Branch | `docs/amend-dod-and-branch-conventions` |
| Owner | Santiago |

**Rama:**
```
docs/amend-dod-and-branch-conventions
```

**Commit:**
```
docs(governance): amend DoD for migrations and contracts, standardize on develop branch
```

**Título del PR:**
```
docs(governance): amend DoD for migrations and contracts, standardize on develop branch
```

**Descripción del PR:**

## Description

### Summary

Updates the Definition of Done, git conventions and documentation rules
to reflect the current architecture (ADR-005 through ADR-009) and
standardizes on `develop` as the branch name across all code
repositories.

### Changes

- **`definition-of-done.md`**: added migration-in-`-db` criterion to
  the integration checklist; OpenAPI contracts cited as source of truth;
  inter-service calls updated for the saga model (ADR-007) and local
  token validation (ADR-006); domain-events criterion notes no events
  in MVP; repo names updated from `auth-service` to `synkro-auth-api`;
  removed `synkro-tech` monolith reference; `docker compose` command
  references `synkro-infra` and `deployment.md` §9; consistency check
  now includes ADR-009.
- **`git-conventions.md`**: all occurrences of `dev` replaced with
  `develop` — the "equivalence note" is removed because the project
  instructions require `develop` explicitly. Affects branch table,
  diagram, team rules, promotion examples, approval table and review
  rule paragraph.
- **`documentation-rules.md`**: compose-service naming updated — `-db`
  repos declare only the migration runner, not a database instance
  (ADR-009).
- **`branching-policy.md`**: no changes needed — already uses `develop`.

### Definition of Done

- [x] `definition-of-done.md` includes migration-in-`-db` criterion
- [x] `definition-of-done.md` integration checklist references OpenAPI contracts as source of truth
- [x] `git-conventions.md` and `branching-policy.md` are consistent — both use `develop`
- [x] No contradictions between the two documents
- [x] Reviewed and approved by Angel (Tech Lead) and Jordan

**Reviewers:** Angel (Tech Lead, validates that the DoD reflects the architecture) and Jordan (reviewed branching-policy, can validate consistency).

Closes HU-DOCS-62 (part of HU-12).
