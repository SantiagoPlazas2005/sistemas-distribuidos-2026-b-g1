# Deployment Environments

> Defines the system's environments, their purposes, access, and key
> configurations. This project has 4 rows in the table below, but 
> only 3 real environment definitions, matching the three permanent Git branches
> (`00-governance/git-conventions.md`) and the three database instances
> `deployment.md` §4 actually defines (`develop`, `qa`, `main` — there is
> no 4th instance for "Local"). **Local and Development are the same
> environment definition** (the `develop` branch, `env/dev.env.example`),
> run at two different moments: Local is a developer running it on their
> own machine before pushing; Development is the same configuration
> validated after a merge, by CI or by whoever is checking integration.
> Neither has a centrally hosted, always-running server — each is a
> separate physical run of `synkro-infra-postgres` (and `synkro-infra-mongo`),
> with its own `synkro-db` and `synkro-mongo` containers, never shared with
> anyone else's run.
>
> `synkro-infra` was renamed to `synkro-infra-postgres` (ADR-010 Decision 6);
> the rename is pending the instructor's action on
> [code-corhuila/synkro-docs#159](https://github.com/code-corhuila/synkro-docs/issues/159).

---

## Project environments

| Environment | Branch | Purpose | Access | Database | Status |
|-------------|--------|---------|--------|----------|--------|
| **Local** | each developer's `feat/*`, `fix/*` or `chore/*` branch, merging into `develop` | Individual development, before pushing | The developer, on their own machine | A `synkro-db` (PostgreSQL) and `synkro-mongo` (MongoDB) instance from the `develop` configuration, run on the developer's own machine (not shared with anyone else's run) | ✅ Active |
| **Development** | `develop` | Validating the `develop` branch after a merge — by CI once it exists, or manually by whoever checks it | Whoever performs the check (any team member) | The same `develop` configuration, run wherever that validation happens (today: manually, on a team member's machine) | ✅ Active |
| **Staging (qa)** | `qa` | Pre-production validation before a release reaches `main` | Team + Product Owner | Separate `synkro-db` and `synkro-mongo` instances for `qa` | 🔴 **Planned** — pending a decision based on progress during the second half of the semester (`01-context/scope.md`); tracked as `15-project-control/open-questions.md` Q-004 |
| **Production (main)** | `main` | The academic project's "production" — no real end users | Team + Product Owner | Separate `synkro-db` and `synkro-mongo` instances for `main` | ✅ Active (academic project, no real end users) |

**What does NOT exist:** a `dev.api.domain.com`-style public URL for any
environment, a secrets vault, Redis, or a Kubernetes cluster. The three
environments run as Docker Compose stacks (`05-architecture/deployment.md`),
reachable only on the machine or CI runner where they are started.

---

## Environment variables per environment

`synkro-infra-postgres/env/` holds one file per environment, each with its
own `COMPOSE_PROJECT_NAME` so an environment never shares a container or a
volume with another:

| Environment | Real file (never committed) | Committed example | `COMPOSE_PROJECT_NAME` |
|---|---|---|---|
| develop | `env/dev.env` | `env/dev.env.example` | `synkro-dev` |
| qa | `env/qa.env` | `env/qa.env.example` | `synkro-qa` |
| main | `env/main.env` | `env/main.env.example` | `synkro-main` |

The real file is created from the matching example and is **never
committed** (`05-architecture/deployment.md` §6, ADR-012 Decision 3).

### Naming convention

Variable names follow the credentials fixed by ADR-012, not a generic
`APP_[SERVICE]_[VARIABLE]` scheme:

```
DB_ADMIN_USER / DB_ADMIN_PASSWORD              — PostgreSQL instance administrator; bootstrap and migration runners only
<DOMAIN>_APP_PASSWORD                          — one per domain; the service user's name is fixed (<domain>_app), only its password is a secret
MONGO_ADMIN_USER / MONGO_ADMIN_PASSWORD        — MongoDB instance administrator; bootstrap and the Liquibase runner only
SALES_APP_PASSWORD                             — synkro-sales-api, connecting as sales_app
JWT_PUBLIC_KEY                                 — every validating service
SERVICE_TOKEN                                  — synkro-workflow, synkro-worker (one each)
```

See the full variable table per service: `05-architecture/deployment.md` §6.

### Where secrets live, per environment

| Environment | Where the real values come from |
|-------------|----------------------------------|
| Local | `env/dev.env`, created from `env/dev.env.example`; generated locally by `./scripts/dev-keys.sh` for the JWT key pair and service tokens |
| Development | The same `env/dev.env.example` convention, with values agreed by the team — not committed |
| Staging (qa) | Not yet provisioned (see the table above) |
| Production (main) | Issued by `synkro-auth-api` once it runs there; stored as CI/CD secrets, never in a repository |

---

## CI/CD Pipeline

See `10-devops/ci-cd.md` for the pipeline steps per repository type. No
pipeline is configured today — until it exists, every check in this
document is run manually, and the Definition of Done says so explicitly
(`00-governance/definition-of-done.md`).

---

## Correlations

- Full deployment topology and composition → `05-architecture/deployment.md`
- How to start the Local environment → `10-devops/local-setup.md`
- CI/CD pipeline design → `10-devops/ci-cd.md`
- Branch strategy these environments mirror → `00-governance/git-conventions.md`
- The `qa` environment decision → `15-project-control/open-questions.md` Q-004
- Instance bootstrap and per-environment files → ADR-012
- Sales domain on MongoDB and repository naming → ADR-010
- Secret management rules → `00-governance/security-policy.md`
