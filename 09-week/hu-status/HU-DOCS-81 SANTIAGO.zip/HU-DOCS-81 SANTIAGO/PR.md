05-architecture/deployment.md
05-architecture/cross-cutting.md
10-devops/environments.md
10-devops/local-setup.md


**Branch:** `docs/update-deployment-for-two-engines-and-environments`
**Commit title:** `docs(architecture): update deployment for two engines and per-environment files`

```markdown
## Description

### Summary

Updates deployment, cross-cutting concerns and onboarding docs for two
database engines (PostgreSQL + MongoDB, ADR-010) and the instance bootstrap
model of ADR-012: one login user per domain created by the instance,
schemas and roles created only by each `-db`, migration runners using the
administrator's credentials, and one environment-variable file per
environment instead of a single `.env`.

### Changes

- **`05-architecture/deployment.md`**: diagram and composition with both
  instances; §4 rewritten as "Database Instances" with the PostgreSQL and
  MongoDB tables and the privilege-check query; §5 migrations use admin
  credentials and add the Sales Liquibase runner; §6 environment files
  (`env/dev.env`, `env/qa.env`, `env/main.env`), the corrected credentials
  table, and per-service variables with fixed usernames; §9 start-from-scratch
  steps rewritten; new §10 for `develop`-only simulated services.
- **`05-architecture/cross-cutting.md`**: Sales' health check now pings
  MongoDB instead of `sales_schema`; a note that Sales' connection-pool
  limits live in its own MongoDB driver variables; references add ADR-010
  and ADR-012.
- **`10-devops/environments.md`**: per-environment files and
  `COMPOSE_PROJECT_NAME`; credential naming convention updated to ADR-012's
  fixed usernames; both instances named throughout.
- **`10-devops/local-setup.md`**: MongoDB port added; clone list includes
  `synkro-infra-mongo`; all commands use `env/dev.env`; migration step
  splits the Flyway loop from the Sales Liquibase runner; troubleshooting
  updated to `up.sh dev` / `down.sh dev`.
- Every mention of the PostgreSQL infrastructure repository uses
  `synkro-infra-postgres`, with a note that the rename
  ([#159](https://github.com/code-corhuila/synkro-docs/issues/159)) is
  still pending the instructor's action.

### Definition of Done

- [x] No document in this PR says `sales_schema`, a single `.env`, or the
      old `<DOMAIN>_DB_USER`/`<DOMAIN>_APP_USER` credential pair
- [x] Every PostgreSQL connection string uses the fixed service-user name
      (`auth_app`, `customers_app`, `products_app`, `workflow_app`); only
      the password is a variable
- [x] Migration runners connect with `DB_ADMIN_USER`/`DB_ADMIN_PASSWORD`,
      never a per-domain owner credential
- [x] The privilege-check query from ADR-012 appears in `deployment.md` §4
- [x] Every mention of the PostgreSQL infra repository says
      `synkro-infra-postgres`, with the pending-rename note
- [x] Reviewed and approved by Angel (Tech Lead) and Santiago

Closes HU-DOCS-81 (part of HU-14).
```
