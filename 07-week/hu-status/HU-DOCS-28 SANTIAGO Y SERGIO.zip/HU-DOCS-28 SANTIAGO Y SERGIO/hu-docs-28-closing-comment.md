**Done.** `git-conventions.md` aligned with `branching-policy.md`, plus
a second occurrence of the same outdated docs-repo workflow found and
fixed in `documentation-rules.md` during review.

## Files

- [`00-governance/git-conventions.md`](https://github.com/code-corhuila/synkro-docs/blob/docs/align-git-conventions/00-governance/git-conventions.md)
- [`00-governance/documentation-rules.md`](https://github.com/code-corhuila/synkro-docs/blob/docs/align-git-conventions/00-governance/documentation-rules.md)

## What changed

**`git-conventions.md`** (commit 1, the professor's checklist):
- added a `dev` = `develop` equivalence note
- made explicit that no permanent branch (`dev`, `qa`, `main`) accepts
  a direct commit
- added the missing `qa/` branch type feeding `qa` — no path into `qa`
  existed before
- fixed `hotfix/` to branch from `main`, not `dev`
- replaced "Merge policy" (which said to use Merge Commit for
  `dev → qa` and `qa → main` — directly contradicting the policy) with
  "Promotion: by re-application, never by merge" (`cherry-pick -x`)
- added the missing "Release branches" section
- added the explicit `ariel5253` approval requirement on `main`,
  clarified it applies to `docs`'s `main` too
- corrected the "Exception: the `docs` repository" section, which
  said "no PR is possible" and described working from a fork — both
  wrong under the new policy

**`documentation-rules.md`** (commit 2, found during review, not in
the original checklist):
- the "Update process" section had the identical outdated claim —
  corrected to describe the same `docs/*` branch + PR + `ariel5253`
  approval flow, kept as its own commit so the git history shows this
  was an additional finding, not silently bundled with commit 1

## Acceptance criteria verified

- [x] All 7 checklist items are verifiably addressed in `git-conventions.md`
- [x] No content the team already wrote was removed without a reason tied to the policy
- [x] `branching-policy.md` itself was not modified
- [x] `documentation-rules.md`'s outdated docs-repo workflow description is corrected, as its own commit
- [ ] Reviewed and approved by at least one other team member

**PR:** #[número del PR]
