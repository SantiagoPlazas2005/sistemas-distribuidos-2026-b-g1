# Deployment Topology

> Defines how the system is composed and run in each environment. Any developer
> must be able to start the complete system by following only this document and
> the repositories it names.

---

## 1. Overview

```
┌──────────────────────────────── Developer machine ─────────────────────────────────┐
│                                                                                     │
│   Browser ──▶ synkro-front :5173 (published)                                        │
│                 └─ serves the four portals as remotes under /remotes/<domain>/      │
│   Browser ──▶ synkro-api-gateway :8000 (published) ── /api/v1/...                   │
│                                                                                     │
│   ┌──────────────────────────── network: platform ────────────────────────────┐    │
│   │                                                                            │    │
│   │   synkro-auth-api ──────▶ auth-db          synkro-workflow ──▶ workflow-db │    │
│   │   synkro-customers-api ─▶ customers-db       │ (saga steps, service token) │    │
│   │   synkro-products-api ──▶ products-db   ◀────┤                             │    │
│   │   synkro-sales-api ─────▶ sales-db      ◀────┘                             │    │
│   │                                                                            │    │
│   │   synkro-worker ──(low-stock job, service token)──▶ synkro-products-api    │    │
│   │                                                                            │    │
│   └────────────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

- Every container joins one network, `platform`. Services and databases declare `expose`, never `ports`: they are reachable inside the network and not from outside.
- Only `synkro-api-gateway` and `synkro-front` publish ports to the host, together with the observability tools (documented with the environment configuration). A published domain service would let any client skip the gateway, its rate limit and its correlation.
- Each domain has its own PostgreSQL instance, and `synkro-workflow` has its own store (ADR-005, ADR-007). The system has no message broker in the MVP (ADR-007).
- `synkrotech_db`, its init script and its per-schema users were never provisioned: they are removed from this document, and nothing is migrated.

---

## 2. Reserved Ports

| Port | Published to the host | Service | Description |
|------|-----------------------|---------|-------------|
| 8000 | Yes | `synkro-api-gateway` | The only entry point to the API |
| 5173 | Yes | `synkro-front` | The web application; serves the portals' remotes |
| 8080 | No | Every `-api`, `synkro-workflow`, each portal | HTTP port inside the network, reached by service name (e.g. `synkro-sales-api:8080`) |
| 5432 | No | `auth-db`, `customers-db`, `products-db`, `sales-db`, `workflow-db` | PostgreSQL inside the network, reached by service name |

`synkro-worker` listens on no port.

---

## 3. Composition

The repositories are cloned as siblings in one workspace. Each one brings its own `deploy/compose.yml`, and `synkro-infra` only puts them together:

| Repository | Brings |
|---|---|
| each `synkro-<domain>-db` | its PostgreSQL instance and its Flyway migration runner |
| each `synkro-<domain>-api`, `synkro-worker` | its own service |
| `synkro-workflow` | its service, `workflow-db` and that store's migration runner |
| `synkro-api-gateway`, `synkro-front`, each portal | its own service |
| `synkro-infra` | only the `include` list, the `platform` network, observability and the development keys; no database statement |

```yaml
# synkro-infra/compose.yml (excerpt)
include:
  - ../synkro-auth-db/deploy/compose.yml
  - ../synkro-auth-api/deploy/compose.yml
  # … the same pair for customers, products and sales
  - ../synkro-workflow/deploy/compose.yml
  - ../synkro-worker/deploy/compose.yml
  - ../synkro-api-gateway/deploy/compose.yml
  - ../synkro-front/deploy/compose.yml
  # … each portal
```

A missing sibling fails visibly when the platform starts; nothing is skipped silently. Each domain can also be started alone from its own repositories.

---

## 4. Database Instances

| Instance | Database and schema | Defined and migrated by | Used only by |
|---|---|---|---|
| `auth-db` | `auth` | `synkro-auth-db` | `synkro-auth-api` |
| `customers-db` | `customers` | `synkro-customers-db` | `synkro-customers-api` |
| `products-db` | `products` | `synkro-products-db` | `synkro-products-api` |
| `sales-db` | `sales` | `synkro-sales-db` | `synkro-sales-api` |
| `workflow-db` | `workflow` | `synkro-workflow` | `synkro-workflow` |

```yaml
# synkro-customers-db/deploy/compose.yml (excerpt; exact image tags are pinned in the repository)
services:
  customers-db:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: customers
      POSTGRES_USER: ${CUSTOMERS_DB_USER}
      POSTGRES_PASSWORD: ${CUSTOMERS_DB_PASSWORD}
    volumes: [customers-db-data:/var/lib/postgresql/data]
    expose: ["5432"]
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -d customers"]
    networks: [platform]

  customers-db-migrate:
    image: flyway/flyway:11-alpine
    profiles: [tooling]              # never started by `up`
    depends_on:
      customers-db: { condition: service_healthy }
    environment:
      FLYWAY_URL: jdbc:postgresql://customers-db:5432/customers
      FLYWAY_USER: ${CUSTOMERS_DB_USER}
      FLYWAY_PASSWORD: ${CUSTOMERS_DB_PASSWORD}
    volumes: ["..:/flyway/project:ro"]
    working_dir: /flyway/project
    command: ["-configFiles=flyway.toml", "migrate"]
    networks: [platform]

volumes:
  customers-db-data:
networks:
  platform: { external: true }
```

Credentials come from the environment (`.env`, never committed); no password is written in any repository.

---

## 5. Migrations

- The schema of each domain lives **only** in its `-db` repository (ADR-005). Services never run migrations at startup.
- A migration is applied **before** deploying the service version that needs it; a breaking change is split into two releases (expand, then contract).
- Each runner uses a pinned image, waits for its database to be healthy, mounts its repository read-only and never starts with the platform.

```bash
# from synkro-infra, once per database
docker compose --env-file .env run --rm customers-db-migrate            # apply
docker compose --env-file .env run --rm customers-db-migrate info       # applied and pending versions
docker compose --env-file .env run --rm customers-db-migrate validate   # checksums of applied migrations
```

Running `migrate` a second time applies zero changes.

---

## 6. Environment Variables per Service

> **Pending update:** this section and "Network Guarantee" below still describe the previous model (shared instance, trusted headers). HU-DOCS-45 rewrites them for one database per domain, token validation in every service and service tokens (ADR-005, ADR-006).

Each service requires the following variables. The values shown are for the local environment.

### auth-service (Java / Spring Boot)

```env
# Database
SPRING_DATASOURCE_URL=jdbc:postgresql://localhost:5432/synkrotech_db?currentSchema=auth
SPRING_DATASOURCE_USERNAME=auth_user
SPRING_DATASOURCE_PASSWORD=auth_pass_dev

# JWT
JWT_PRIVATE_KEY=-----BEGIN RSA PRIVATE KEY-----\n...\n-----END RSA PRIVATE KEY-----
JWT_PUBLIC_KEY=-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----
JWT_ACCESS_TOKEN_EXPIRATION=3600
JWT_REFRESH_TOKEN_EXPIRATION=604800

# Flyway
SPRING_FLYWAY_SCHEMAS=auth
SPRING_FLYWAY_DEFAULT_SCHEMA=auth

# Server
SERVER_PORT=8081
```

### customers-service (Java / Spring Boot)

```env
# Database
SPRING_DATASOURCE_URL=jdbc:postgresql://localhost:5432/synkrotech_db?currentSchema=customers
SPRING_DATASOURCE_USERNAME=customers_user
SPRING_DATASOURCE_PASSWORD=customers_pass_dev

# Trusted headers (forwarded by api-gateway, ADR-003 §2)
# No JWT validation here — see 05-architecture/deployment.md
# "Network Guarantee" section for why this is safe

# Flyway
SPRING_FLYWAY_SCHEMAS=customers
SPRING_FLYWAY_DEFAULT_SCHEMA=customers

# Server
SERVER_PORT=8082
```

### products-service (Go)

```env
# Database
DATABASE_URL=postgresql://products_user:products_pass_dev@localhost:5432/synkrotech_db?search_path=products&sslmode=disable

# Trusted headers (forwarded by api-gateway, ADR-003 §2)
# No JWT validation here — see 05-architecture/deployment.md
# "Network Guarantee" section for why this is safe

# Server
SERVER_PORT=8083
```

### sales-service (Go)

```env
# Database
DATABASE_URL=postgresql://sales_user:sales_pass_dev@localhost:5432/synkrotech_db?search_path=sales&sslmode=disable

# Trusted headers (forwarded by api-gateway, ADR-003 §2)
# No JWT validation here — see "Network Guarantee" section below

# Outbox relay (ADR-003 §5)
RABBITMQ_URL=amqp://synkro:synkro_dev_2026@localhost:5672/
OUTBOX_RELAY_INTERVAL=2s

# Server
SERVER_PORT=8084
```

### api-gateway

```env
# JWT validation (the only service that still validates it)
JWT_PUBLIC_KEY=-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----

# Routing targets
AUTH_SERVICE_URL=http://localhost:8081
CUSTOMERS_SERVICE_URL=http://localhost:8082
PRODUCTS_SERVICE_URL=http://localhost:8083
SALES_SERVICE_URL=http://localhost:8084
WORKFLOW_SERVICE_URL=http://localhost:PORT_TBD

# Rate limiting (values are placeholders — tune once real traffic is observed)
RATE_LIMIT_REQUESTS_PER_MINUTE=100

# Server
SERVER_PORT=PORT_TBD
```

### synkro-workflow

```env
# No database — stateless orchestrator (ADR-003 §4)

# Saga step targets
CUSTOMERS_SERVICE_URL=http://localhost:8082
PRODUCTS_SERVICE_URL=http://localhost:8083
SALES_SERVICE_URL=http://localhost:8084

# Timeouts (moved here from sales-service, pattern-guide.md §5)
HTTP_TIMEOUT_READ=3s
HTTP_TIMEOUT_WRITE=5s

# Server
SERVER_PORT=PORT_TBD
```

### synkro-worker

```env
# No database, no HTTP server (ADR-003 §4)

# RabbitMQ consumer
RABBITMQ_URL=amqp://synkro:synkro_dev_2026@localhost:5672/
RABBITMQ_QUEUE=sale-events

# For jobs that call back into domain services (e.g., re-check a sale)
SALES_SERVICE_URL=http://localhost:8084
```

## Network Guarantee — JWT Header Trust (ADR-003 §2)

ADR-003 moved JWT validation from each domain service to the API
Gateway, which forwards trusted headers (`X-User-Id`, `X-User-Roles`)
to downstream services. **This is secure only if no external traffic
can reach a domain service without passing through the Gateway.**

In the local development environment (Docker Compose), this is enforced
by network configuration:

```yaml
networks:
  synkro-internal:
    driver: bridge
    internal: true     # no external access
  synkro-external:
    driver: bridge

services:
  api-gateway:
    networks:
      - synkro-external   # reachable from outside (frontends)
      - synkro-internal   # can reach domain services

  auth-service:
    networks:
      - synkro-internal   # NOT on synkro-external → unreachable from outside
  customers-service:
    networks:
      - synkro-internal
  products-service:
    networks:
      - synkro-internal
  sales-service:
    networks:
      - synkro-internal
  workflow:
    networks:
      - synkro-internal
  worker:
    networks:
      - synkro-internal
  rabbitmq:
    networks:
      - synkro-internal
```

**The `internal: true` flag on `synkro-internal`** prevents Docker from
creating a default route to the host network — containers on that
network can only talk to each other, never to the outside. The Gateway
is the only service on both networks, making it the only external door.

**Accepted risk (documented in ADR-003 §2):** if this network
configuration is bypassed (e.g., by exposing a domain service's port
directly in docker-compose with `ports:`), any forged `X-User-Id`
header would be accepted as valid. This is a configuration error, not
a design flaw — the mitigation is to never expose domain service ports
on the host, only the Gateway's port.

---

## 7. How to Start Everything from Scratch

```bash
# 1. Clone every repository as a sibling of synkro-infra, then:
cd synkro-infra
cp env/.env.develop.example .env        # set every *_DB_PASSWORD
./scripts/dev-keys.sh                   # develop only: key pair, JWT_PUBLIC_KEY, SERVICE_TOKEN
./scripts/up.sh                         # checks .env, creates the platform network, starts everything

# 2. Migrate each database (once per -db, and after pulling new migrations)
for db in auth customers products sales workflow; do
  docker compose --env-file .env run --rm "$db-db-migrate"
done

# 3. Verify
docker compose ps                                        # every service healthy
curl http://localhost:8000/health                        # gateway
curl -H "Authorization: Bearer $(./scripts/dev-token.sh alice)" \
     http://localhost:8000/api/v1/customers              # routed and validated by synkro-customers-api
docker compose logs synkro-worker                        # one entry per low-stock run
```

Until a schema is migrated, that domain's API answers `500 INTERNAL_ERROR` and the worker logs the failed run with its `traceId`; the next run works once the migration is applied.

---

## Correlations

* Database per domain and migrations → ADR-005
* Token validation and service tokens → ADR-006 (environment details in §6, updated by HU-DOCS-45)
* Workflow store and worker job → ADR-007
* Gateway and frontend technology → ADR-008
* Timeout and retry configuration → `05-architecture/pattern-guide.md` §5
* Data model per domain → `06-data/models.md`
