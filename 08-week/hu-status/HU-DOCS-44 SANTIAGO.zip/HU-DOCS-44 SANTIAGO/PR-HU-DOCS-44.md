# PR — HU-DOCS-44

**Branch:** `docs/rewrite-deployment-composition-and-migrations` → `main`

**Title:**

```
docs(architecture): rewrite deployment composition, database instances and migrations
```

**Description:**

```markdown
## User story

Closes #66 — HU-DOCS-44: `deployment.md` part 1, composition, database instances and migrations (part of HU-10 #59)

## What changes and why

`05-architecture/deployment.md` still described one shared `synkrotech_db` instance with an init script, per-schema users and `GRANT`s, services running their own migrations at startup, RabbitMQ, and ports marked TBD. ADR-005, ADR-007 and ADR-008 replaced all of that.

- **§1 Overview:** new topology. One `platform` network; four domain databases plus `workflow-db`; only the gateway (`8000`) and the frontend (`5173`) are published; no broker. It states explicitly that `synkrotech_db`, its init script and its per-schema users were never provisioned, so nothing is migrated.
- **§2 Reserved Ports:** published ports (gateway, frontend) and internal ports reached by service name (`8080` for HTTP services, `5432` for databases).
- **§3 Composition:** what each repository brings, and the `include` list of `synkro-infra`, which holds no database statement.
- **§4 Database Instances:** one instance per domain plus the workflow store, with an excerpt of a `-db` repository's `deploy/compose.yml` and its Flyway runner.
- **§5 Migrations:** migrations live only in each `-db`, run before the service version that needs them, and use a pinned runner that never starts with the platform; `migrate`, `info` and `validate` commands.
- **§7 How to Start:** `.env`, development keys, `up.sh`, one migration per database, verification through the gateway.
- **§6 and "Network Guarantee"** are left unchanged, with a note: HU-DOCS-45 rewrites them for one database per domain, token validation in every service and service tokens.

## Automated review traceability

Answers finding 1 of the ADR-005 review: §1 now states that `synkrotech_db` and its permissions were never provisioned and are removed, not kept.

## Design details for the reviewers

- `synkro-front` publishes `5173` and serves the four portals' remotes under `/remotes/<domain>/` through its own NGINX, so no portal and no domain service is published.
- Every HTTP service listens on `8080` inside its container and every database on `5432`; each one is reached by its service name.

## How it was checked

- No shared instance, init script, schema `GRANT`, service-run migration or RabbitMQ remains outside the two sections that HU-DOCS-45 rewrites.
- 380 changed lines.

## Checklist

- [ ] Reviewed by at least one team member
- [ ] Consistent with ADR-005, ADR-007 and ADR-008
- [ ] At most 400 changed lines
```

**Depends on:** ADR-005 (#61), ADR-007 (#63) and ADR-008 (#64) merged.
